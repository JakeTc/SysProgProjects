#ifndef _MULTITEST_H
#define _MULTITEST_H
#define dummy(w, x, y, z) variableSearch(w, x, y, z)
int variableSearch(int,int*,int,int);
extern const char* mode;
#endif

